
   function getChocolateNome(chocolateId) {
       const chocolates = {
           'chocolateAoLeite': 'Chocolate ao Leite',
           'trufaDeMorango': 'Trufa de Morango',
           'tableteDeChocolateAmargo': 'Tablete de Chocolate Amargo'
       };
       return chocolates[chocolateId] || 'Chocolate Desconhecido';
   }

   function getChocolatePreco(chocolateId) {
       const precos = {
           'chocolateAoLeite': 15.00,
           'trufaDeMorango': 20.00,
           'tableteDeChocolateAmargo': 12.00
       };
       return precos[chocolateId] || 0.00;
   }
   
  

   
   function simularCompra(chocolateId) {
       const chocolateNome = getChocolateNome(chocolateId);
       const chocolatePreco = getChocolatePreco(chocolateId);

       alert(`Compra simulada: ${chocolateNome} - Preço: R$${chocolatePreco.toFixed(2)}`);
   }
